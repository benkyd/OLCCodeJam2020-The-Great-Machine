# The Great Machine

The theme was the great machine and i sort of went for a rhetoric on mental health and society being "the great machine"

If your demons destroy you, you loose

If you use your health to destroy your demons, you win
If you outrun your demons, you win

Good luck

## Credit

David Lees - SFX

